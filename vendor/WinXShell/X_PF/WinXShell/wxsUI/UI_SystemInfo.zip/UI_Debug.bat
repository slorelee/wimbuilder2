call :GetUIName "%cd%"
cd /d "%~dp0..\.."
call :GetWinXShell

start "" %WINXSHELL% -ui -console -jcfg wxsUI\%UIName%\main.jcfg
pause
start "" %WINXSHELL% -ui -console -jcfg wxsUI\%UIName%\main.jcfg -theme dark
pause
start "" %WINXSHELL% -ui -console -jcfg wxsUI\%UIName%\main.jcfg -theme light
goto :EOF

:GetUIName
set UIName=%~n1
goto :EOF

:GetWinXShell
if exist x64\Debug\WinXShell.exe set WINXSHELL=x64\Debug\WinXShell.exe&&goto :EOF
if exist WinXShell.exe set WINXSHELL=WinXShell.exe&&goto :EOF
if exist WinXShell_%PROCESSOR_ARCHITECTURE%.exe set WINXSHELL=WinXShell_x86.exe&&goto :EOF
set WINXSHELL=WinXShell_x64.exe
goto :EOF

