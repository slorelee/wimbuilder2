
local ElemPgBar = nil
local ElemPgInfo = nil

function UIWindow.OnLoad()
    App.Print('UIWindow.OnLoad()')
    UI:SetTimer('Progressbar Control 1 to 100', 1000)
    ElemPgBar = sui:find('pgBar')
    ElemPgInfo = sui:find('pgInfo')
    UIWindow.Inited = 1
end

UI.OnClick['btnClickMe'] = function()
    App.Print("UI.OnClick['btnClickMe']")
    local edit1 = sui:find('txtInput')
    Alert(edit1:gettext())
    sui:find('btnClickMe'):settext('abc')
    edit1:settext('edit123')
    Alert(edit1.text) 
end

UI.OnTimer['Progressbar Control 1 to 100'] = function(tid)
    local val = ElemPgBar.value
    val = tonumber(val) + math.random(2, 8)
    if val > 100 then val = 100 end
    ElemPgBar.value = val
    ElemPgInfo.text = string.format("��ǰ���� %d %%", val)
    if val == 100 then
        UI:KillTimer(tid)
        winapi.show_message("֪ͨ", "���ȴﵽ 100%, ��ҵ����ɡ�")
    end
end

UI.OnClick['btnOK'] = function()
    winapi.show_message("Hello", "OK")
end

UI.OnClick['btnCancel'] = function()
    sui:close()
end