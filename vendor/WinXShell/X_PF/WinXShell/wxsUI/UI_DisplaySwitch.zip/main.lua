local elemListMode = nil

UI.OnChanged['list_mode'] = function()
    if not elemListMode then
        elemListMode = sui:find('list_mode')
    end
    local mode = elemListMode.index
    if mode == 0 then
        App:Run('DisplaySwitch.exe', '/internal')
    elseif mode == 1 then
        App:Run('DisplaySwitch.exe', '/clone')
    elseif mode == 2 then
        App:Run('DisplaySwitch.exe', '/extend')
    elseif mode == 3 then
        App:Run('DisplaySwitch.exe', '/external')
    end
end

UI.OnClick['btnOK'] = function()
    MsgBox("Hello", "OK")
end

UI.OnClick['btnCancel'] = function()
    sui:close()
end