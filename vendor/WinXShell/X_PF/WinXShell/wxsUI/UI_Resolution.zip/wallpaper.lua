
function onload()
    mypath = sui:jcfg('name')
end

function onclick(ctrl)
    if ctrl == "wp_broswerbtn" then
        App:Run('pecmd.exe', '.\\' .. mypath .. '\\wp_script.ini select')
    elseif ctrl == "wp_searchbtn" then
        App:Run('pecmd.exe', '.\\' .. mypath .. '\\wp_script.ini random')
    elseif ctrl == "wp_defaultbtn" then
        App:Run('pecmd.exe', 'WALL X:\\system32\\winpe.jpg')
    elseif ctrl == "cancelbtn" then
        sui:close()
    end
end
