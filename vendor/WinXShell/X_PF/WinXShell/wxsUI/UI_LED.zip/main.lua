
show_text = " The quick brown fox jumps over a lazy dog"
lshift_index = 0
char_width = 2

TIMER_ID_FLUSH_TEXT = 1001
TIMER_ID_QUIT = 1002

function lshift_text()
   local new_text = show_text:sub(lshift_index + 1)
   lshift_index = lshift_index + char_width  -- ȫ���֣�һ���ƶ�2���ֽ�
   if lshift_index > show_text:len() then lshift_index = 0 end
   elem_label_info.text = "<b>" .. new_text .. "</b>"
   elem_label_info.bkcolor = "#FEFFFFFF"
end

function move_top()
  local w, h = sui:info('wh')
  if  App:HasOption('-top') then
    -- �ƶ�������
    sui:move( 0, - ((Screen:GetY() - h) // 2), 0, 0)
  end
end

function onload()
  local text = App:GetOption('-text')
  local wait = App:GetOption('-wait')
  -- winapi.show_message(text, wait)
  if text then
    if text:sub(1, 1) == '"' then text = text:sub(2, -2) end
    show_text = text
  end
  elem_label_info = sui:find('label_info')
  elem_label_info.text = "<b>" ..  show_text .. "</b>"

  -- ���������ݵ����������
  local def_w, w
  def_w = sui:info('wh')

  move_top()

  w = #show_text // char_width * 42 -- ȫ���֣�һ������ռ2���ֽ�
  if show_text:sub(1, 1) == ' ' then
    char_width = 1
    show_text = show_text:sub(2, -1)
    w = #show_text * 20
  end
  if w > Screen:GetX() then w = Screen:GetX() end
  if w > def_w then
    w = w - def_w
    sui:move(- w // 2, 0, w, 0)
  end

  if  App:HasOption('-scroll') then
    -- ������ʱ�������ֹ���Ч��
    suilib.call('SetTimer', TIMER_ID_FLUSH_TEXT, 300)
  end

  if wait then
    suilib.call('SetTimer', TIMER_ID_QUIT, wait * 1000)
  end
end

function ontimer(id)
   if id == TIMER_ID_QUIT then
     sui:close()
   elseif id == TIMER_ID_FLUSH_TEXT then
     lshift_text()
   end
end

function ondisplaychanged()
  move_top()
end
