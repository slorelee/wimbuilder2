UIPages['Background'] = {
  Name = 'Background'
}

local Msg_CommonPic = sui:i18n('CommonPic')
local Msg_AllPic = sui:i18n('AllPic')

local function update_history_paths(bkMode)
  local wallpaper = ''
  if bkMode ~= '0' then return end
  for i = 0, 4 do
    wallpaper = Reg:Read([[HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\Wallpapers]],
      'BackgroundHistoryPath' .. tostring(i))
    if i == 0 and wallpaper == nil then
      wallpaper = Reg:Read([[HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\Wallpapers]], 'CurrentWallpaperPath')
      if wallpaper == nil then
        wallpaper = Desktop:GetWallpaper()
      end
    end
    if wallpaper then 
      sui:find('$BG.Preset[' .. tostring(i) .. ']').bkimage = wallpaper
    end
  end
end

local function update_current_wallpaper(bkMode)
  local path0 = Reg:Read([[HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\Wallpapers]], 'BackgroundHistoryPath0')
  local wallpaper = path0
  if wallpaper == nil then
    wallpaper = Reg:Read([[HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\Wallpapers]], 'CurrentWallpaperPath')
  end
  if wallpaper == nil then
    wallpaper = Desktop:GetWallpaper()
  end

  if path0 == nil and os.info('isWinPE') and wallpaper then
    Reg:Write([[HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\Wallpapers]], 'BackgroundHistoryPath0', wallpaper)
  end

  if bkMode == '0' then
    sui:find('currentWallpaper').bkimage = wallpaper
  elseif bkMode == '1' then
    local c_color = Reg:Read([[HKEY_CURRENT_USER\Control Panel\Colors]], 'Background')
    local valR, valG, valB = string.match(c_color, "(%d+) (%d+) (%d+)")
    local rgbColor = string.format("color='#ff%02x%02x%02x'", valR, valG, valB)
    sui:find('currentWallpaper').bkimage = rgbColor
  end
end

local function switch_panel_main(bkMode)
  if bkMode == '0' then
    sui:find('Perset_Pic').visible = 1
    sui:find('Browse').visible = 1
    sui:find('Show_Mode_Option').visible = 1
    sui:find('Perset_Color').visible = 0
    sui:find('Browse_Color').visible = 0
    sui:find('View_SlideShow').visible = 0
  elseif bkMode == '1' then
    sui:find('Perset_Pic').visible = 0
    sui:find('Browse').visible = 0
    sui:find('Show_Mode_Option').visible = 0
    sui:find('Perset_Color').visible = 1
    sui:find('Browse_Color').visible = 1
    sui:find('View_SlideShow').visible = 0
  elseif bkMode == '2' then
    sui:find('Perset_Pic').visible = 0
    sui:find('Show_Mode_Option').visible = 1
    sui:find('Browse').visible = 0
    sui:find('Perset_Color').visible = 0
    sui:find('Browse_Color').visible = 0
    sui:find('View_SlideShow').visible = 1
  end

  update_history_paths(bkMode)
  update_current_wallpaper(bkMode)
end

---

UIPages['Background'].Init = function(self, tab)
  tab:OnClick(self.Name) -- be visible for changing combobox index

  bkMode = Reg:Read([[HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\Wallpapers]], 'BackgroundType')
  if bkMode == nil then bkMode = '0' end
  switch_panel_main(tostring(bkMode))
  sui:find('Background_combo').index = bkMode
  bkShowMode1 = Reg:Read([[HKEY_CURRENT_USER\Control Panel\Desktop]], 'WallpaperStyle') 
  bkShowMode2 = Reg:Read([[HKEY_CURRENT_USER\Control Panel\Desktop]], 'TileWallpaper')
  bkSMCombo = sui:find('Show_Mode_combo')
  App.Print(type(bkMode))
  if bkShowMode2 == '1' then
    bkSMCombo.index = 3
  elseif bkShowMode1 == '10' then
    bkSMCombo.index = 0
  elseif bkShowMode1 == '6' then
    bkSMCombo.index = 1
  elseif bkShowMode1 == '2' then
    bkSMCombo.index = 2
  elseif bkShowMode1 == '0' then
    bkSMCombo.index = 4
  elseif bkShowMode1 == '22' then
    bkSMCombo.index = 5
  end
  -- UI:SetTimer('WallpaperTimer', 1000)
end

UI.OnTimer['WallpaperTimer'] = function()
  sui:find('currentWallpaper').bkimage = Desktop:GetWallpaper()
  bkMode = Reg:Read([[HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\Wallpapers]], 'BackgroundType')
end

UI.OnClick['currentWallpaper'] = function()
  local filterinfo = Msg_CommonPic .. '|*.png;*.jpg;*.jpeg;*.bmp|'
  filterinfo = filterinfo .. Msg_AllPic .. '|*.jpg;*.jpeg;*.bmp;*.dib;*.png;*.jfif;*.jpe;*.gif;*.tif;*.tiff;*.wdp;*.heic;*.heif;*.heics;*.heifs;*.hif;*.avci;*.avcs;*.avif;*.avifs;*.jxr;*.jxl'

  local path = Dialog:OpenFile('', filterinfo)
  if path ~= '' then
    Desktop:SetWallpaper(path)
    sui:find('currentWallpaper').bkimage = path
    update_history_paths('0')
  end
end

UI.OnClick['btnSelectCustom'] = function()
    UI.OnClick['currentWallpaper']()
end

UI.OnChanged['Background_combo'] = function(val)
  App.Print(val)
  switch_panel_main(tostring(val))
  if val == 0 then
    Desktop:SetWallpaper(sui:find('currentWallpaper').bkimage)
  elseif val == 1 then
    Desktop:SetWallpaper('')
  elseif val == 2 then
  end
  Reg:Write([[HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\Wallpapers]], 'BackgroundType', val)
end

local BGPresetButtons = {}
function BGPresetButtons:OnClick(preset, ctrl)
  local histroy_path = sui:find(ctrl).bkimage
  if histroy_path ~= '' then
    Desktop:SetWallpaper(histroy_path)
    sui:find('currentWallpaper').bkimage = histroy_path
  end
end

local BGColorButtons = {}
function BGColorButtons:OnClick(color, ctrl)
    sui:find('currentWallpaper').bkimage = "color='" .. color .. "'"
    Desktop:SetColor(color)
end

UIEvent.BindOnClick('$BG.Preset', BGPresetButtons)
UIEvent.BindOnClick('$BG.Color', BGColorButtons)

UI.OnClick['btnSelectCustomColor'] = function()
  local customcolor = Dialog:ChooseColor(sui:info('hwnd'))
  if customcolor ~= -1 then
    BGColorButtons:OnClick(string.format('#%06x', customcolor), 'dummy')
  end
  -- App:Run(App.Path .. [[\SetDesktop.exe ]], '--custom-color')
end

UI.OnClick['btnView_SlideShow'] = function()
  local f = Dialog:BrowseFolder('Select')
  App:Run(App.Path .. [[\SetDesktop.exe ]],'--slideshow ' .. f .. ' --shuffle')
end

UI.OnChanged['Show_Mode_combo'] = function(val)
  App.Print(val)
  local wallpaperstyle = 10
  local tilewallpaper = 0
  if val == 0 then
    wallpaperstyle = 10
  elseif val == 1 then
    wallpaperstyle = 6
  elseif val == 2 then
    wallpaperstyle = 2
  elseif val == 3 then
    wallpaperstyle = 0
    tilewallpaper = 1
  elseif val == 4 then
    wallpaperstyle = 0
  elseif val == 5 then
    wallpaperstyle = 22
  end
  Reg:Write ([[HKEY_CURRENT_USER\Control Panel\Desktop]], 'WallpaperStyle', wallpaperstyle)
  Reg:Write ([[HKEY_CURRENT_USER\Control Panel\Desktop]], 'TileWallpaper', tilewallpaper)
  App:Call('Desktop::UpdateWallpaper')
end
